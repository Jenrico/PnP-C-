﻿// Jacob Enrico 10/20/18
// U.R.II Project

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;

namespace Demo_1_2
{
    public partial class Form1 : Form
    {
        private VideoCapture _capture;
        private Thread _captureThread;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _capture = new VideoCapture(1);
            _captureThread = new Thread(DisplayWebcam);
            _captureThread.Start();
        }

        //MAIN BODY OF CODE//
        private void DisplayWebcam()
        {
            while (_capture.IsOpened)
            {
                Mat sourceFrame = _capture.QueryFrame();
                int newHeight = (sourceFrame.Size.Height * sourcePictureBox.Size.Width) / sourceFrame.Size.Width;
                Size newSize = new Size(sourcePictureBox.Size.Width, newHeight);
                CvInvoke.Resize(sourceFrame, sourceFrame, newSize);
                sourcePictureBox.Image = sourceFrame.Bitmap;
                Mat sourceFrameWithArt = sourceFrame.Clone();
                Image<Bgr, byte> sourceFrameWarped = sourceFrame.ToImage<Bgr, byte>();
                Image<Gray, byte> grayImg = sourceFrame.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new Gray(255));

                using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                {

                    //Finding contours
                    CvInvoke.FindContours(grayImg, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                    if (contours.Size > 0)
                    {
                        double maxArea = 0;
                        int chosen = 0;
                        for (int i = 0; i < contours.Size; i++)
                        {
                            VectorOfPoint contour = contours[i];
                            double area = CvInvoke.ContourArea(contour);
                            if (area > maxArea)
                            {
                                maxArea = area;
                                chosen = i;
                            }
                        }
                        Rectangle boundingBox = CvInvoke.BoundingRectangle(contours[chosen]);
                        MarkDetectedObject(sourceFrameWithArt, contours[chosen], boundingBox, maxArea);
                        sourceFrameWarped.ROI = new Rectangle((int)Math.Min(0, boundingBox.X - 30),
                        (int)Math.Min(0, boundingBox.Y - 30),
                        (int)Math.Max(sourceFrameWarped.Width - 1, boundingBox.X + boundingBox.Width + 30),
                        (int)Math.Max(sourceFrameWarped.Height - 1, boundingBox.Y + boundingBox.Height + 30));
                        Mat warpedImage = WarpImage(sourceFrameWarped, contours[chosen]).Mat;
                        warpedPictureBox.Image = warpedImage.Bitmap;
                       
                        var blurredImage = new Mat();
                        var cannyImage = new Mat();
                        var cannyImageDecorated = new Mat();
                        
                        //Sharpening image to find contours
                        CvInvoke.GaussianBlur(warpedImage, blurredImage, new Size(3, 3), 0);

                        CvInvoke.CvtColor(blurredImage, blurredImage, typeof(Bgr), typeof(Gray));

                        CvInvoke.Canny(blurredImage, cannyImage, 150, 255);

                        CvInvoke.CvtColor(cannyImage, cannyImageDecorated, typeof(Gray), typeof(Bgr));

                        using (VectorOfVectorOfPoint contours2 = new VectorOfVectorOfPoint())
                            {
                                CvInvoke.FindContours(cannyImage, contours2, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);

                                for (int i = 0; i < contours2.Size; i++)
                                {
                                    VectorOfPoint contour2 = contours2[i];
                                Rectangle boundingBox2 = CvInvoke.BoundingRectangle(contours[chosen]);
                                double area2 = CvInvoke.ContourArea(contour2);
                                MarkDetectedObject(cannyImageDecorated, contour2, boundingBox2, area2);
                                }

                            Invoke(new Action(() =>
                            {
                                label6.Text = $"Contours: {contours2.Size}";
                            }));
                        }
                        warpedPictureBox.Image = warpedImage.Bitmap;
                        counterImage.Image = cannyImageDecorated.Bitmap;
                    }
                }
            }
        }

        //WARP IMAGE - To snap the image to the paper//
        private static Image<Bgr, Byte> WarpImage(Image<Bgr, byte> frame, VectorOfPoint contour2)
        {
            var size = new Size(frame.Width, frame.Height);
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                //Finding contours to find paper
                CvInvoke.ApproxPolyDP(contour2, approxContour, CvInvoke.ArcLength(contour2, true) * 0.05, true);
                Point[] points = approxContour.ToArray();
                if (points.Length != 4)
                {
                    for (int i = 0; i < points.Length; i++)
                    {
                        frame.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);
                    }
                    return frame;
                }
                IEnumerable<Point> query = points.OrderBy(point => point.Y).ThenBy(point => point.X);
                PointF[] ptsSrc = new PointF[4];
                PointF[] ptsDst = new PointF[] { new PointF(0, 0), new PointF(size.Width - 1, 0), new PointF(0, size.Height - 1),
                        new PointF(size.Width - 1, size.Height - 1) };
                for (int i = 0; i < 4; i++)
                {
                    ptsSrc[i] = new PointF(query.ElementAt(i).X, query.ElementAt(i).Y);
                }
                using (var matrix = CvInvoke.GetPerspectiveTransform(ptsSrc, ptsDst))
                {
                    using (var cutImagePortion = new Mat())
                    {
                        CvInvoke.WarpPerspective(frame, cutImagePortion, matrix, size, Inter.Cubic);
                        return cutImagePortion.ToImage<Bgr, Byte>();
                    }
                }
            }
        }
        //DETECTING SHAPES//
        private static void MarkDetectedObject(Mat frame, VectorOfPoint contour2, Rectangle boundingBox, double area)
        {
            Color lineColor = Color.Orange;

            //Finding area to compare for shape detection
            double contourArea = CvInvoke.ContourArea(contour2);
            double totalArea = boundingBox.Height * boundingBox.Width;

            double percArea = contourArea / totalArea;

            if(percArea > .75)
            {
                lineColor = Color.Red;
            }

            else
            {
                lineColor = Color.Green;
            }

            CvInvoke.Polylines(frame, contour2, true, new Bgr(lineColor).MCvScalar);
            CvInvoke.Rectangle(frame, boundingBox, new Bgr(lineColor).MCvScalar);

            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);

            //Writing centriod coordinates
            var info = new string[] 
            {
                $"Area: {area}",
                $"Position: {center.X}, {center.Y}"
            };
            WriteMultilineText(frame, info, new Point(center.X, boundingBox.Bottom + 12));
        }
        private static void WriteMultilineText(Mat frame, string[] lines, Point origin)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y;
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                FontFace.HersheyPlain, 0.8, new Bgr(Color.Red).MCvScalar);
            }
        }

        private void emguPictureBox_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _captureThread.Abort();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void counterImage_Click(object sender, EventArgs e)
        {

        }

        private void roiPictureBox_Click(object sender, EventArgs e)
        {

        }
    }
}
